#
#   Library
#

from . import batchread
